package com.example.readify.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.readify.R

class Home2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home2)
    }
}